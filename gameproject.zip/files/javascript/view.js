
    const containx = document.getElementById("main-navbar");

    window.addEventListener("scroll", () => {
    let scrolly = window.scrollY;
    if (scrolly > 100) {
    const containxr = document.getElementById("main-navbar");

    containxr.classList.add("hrmx");


}
    else if(scrolly < 50) {
    containx.classList.replace("hrmx","hrx");
}

});
    const show = document.querySelector("#agent");
    const degisen = document.querySelector("#underlist");
    const ekle = document.querySelector("#rightbar");
    const th = document.querySelector("#th");
    show.addEventListener("click",()=> {
    degisen.classList.toggle("showmenu");
    ekle.classList.toggle("nav-right-act");
    ekle.classList.toggle("animate");
    degisen.classList.toggle("animate");

});

    const theme = document.querySelector("#theme");
    const degis = document.querySelector("#degis");
    const mainsection = document.querySelector("#main");
    const mainpost = document.querySelector("#main-posts-theme");

    theme.addEventListener("click", ()=>{
    th.classList.toggle("fa-moon");
    mainsection.classList.toggle("section-theme");
    mainpost.classList.toggle("main-theme");

})

    const agr = document.querySelector("#xmark");
    agr.addEventListener("click", ()=> {
    agr.classList.toggle("transition");
    agr.classList.toggle("fa-xmark");
})


